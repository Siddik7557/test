// In your main server.js file
app.use('/api/ai-automations', require('./routes/aiAutomationRoutes'));
