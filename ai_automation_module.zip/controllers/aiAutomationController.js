const AIAutomation = require('../models/AIAutomation');

exports.createAutomation = async (req, res) => {
  try {
    const newAutomation = new AIAutomation(req.body);
    const saved = await newAutomation.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAllAutomations = async (req, res) => {
  try {
    const list = await AIAutomation.find().populate('triggeredBy');
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAutomation = async (req, res) => {
  try {
    const task = await AIAutomation.findById(req.params.id).populate('triggeredBy');
    if (!task) return res.status(404).json({ message: 'Not found' });
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateAutomation = async (req, res) => {
  try {
    const updated = await AIAutomation.findByIdAndUpdate(
      req.params.id,
      { ...req.body, updatedAt: new Date() },
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
