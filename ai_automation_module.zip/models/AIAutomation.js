const mongoose = require('mongoose');

const AIAutomationSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['summary', 'reminder', 'chatbot', 'followup', 'recommendation'],
    required: true
  },
  input: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  output: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  triggeredBy: {
    type: mongoose.Schema.Types.ObjectId,
    refPath: 'triggerSource',
    required: true
  },
  triggerSource: {
    type: String,
    enum: ['Doctor', 'Patient', 'Appointment', 'System'],
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: Date
});

module.exports = mongoose.model('AIAutomation', AIAutomationSchema);
