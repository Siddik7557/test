const express = require('express');
const router = express.Router();
const {
  createAutomation,
  getAllAutomations,
  getAutomation,
  updateAutomation
} = require('../controllers/aiAutomationController');

router.post('/', createAutomation);
router.get('/', getAllAutomations);
router.get('/:id', getAutomation);
router.put('/:id', updateAutomation);

module.exports = router;
